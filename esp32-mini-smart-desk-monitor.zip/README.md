# ESP32 Mini Smart Desk Monitor

A compact ESP32 desk display that combines a Wi-Fi-synchronized clock with live temperature and humidity readings on an OLED screen.

## Problem solved

A normal desk clock only gives the time, while checking temperature and humidity usually requires opening an app, using a separate thermometer/hygrometer, or relying on a larger smart-home device. This project puts those three useful pieces of information in one small, USB-powered display that can sit on a desk, workstation, gaming setup, or dashboard.

## Features

- Wi-Fi synchronized clock using NTP
- Live temperature monitoring
- Live humidity monitoring
- 128×64 I2C OLED display
- USB powered through the ESP32
- Compact custom handmade metal frame
- Simple firmware that can be expanded with more sensors/features

## Hardware

- ESP32 development board
- 0.96-inch SSD1306 128×64 I2C OLED
- DHT11 or DHT22 temperature/humidity sensor
- Jumper wires
- USB cable/power source
- Custom metal frame/enclosure

## Wiring

### OLED (SSD1306 I2C)

| OLED | ESP32 |
|---|---|
| VCC | 3.3V |
| GND | GND |
| SDA | GPIO 21 |
| SCL | GPIO 22 |

### DHT sensor

| DHT | ESP32 |
|---|---|
| VCC | 3.3V |
| GND | GND |
| DATA | GPIO 4 |

For a bare DHT sensor, use the pull-up resistor recommended by the sensor module/datasheet. Many DHT modules already include it.

## Arduino IDE setup

Install the ESP32 board package, then install these libraries from Library Manager:

- Adafruit SSD1306
- Adafruit GFX Library
- DHT sensor library by Adafruit
- Adafruit Unified Sensor

Open `src/esp32_smart_desk_monitor.ino`, change the Wi-Fi credentials and upload it to the ESP32.

## Configuration

At the top of the sketch:

```cpp
const char* WIFI_SSID = "YOUR_WIFI_NAME";
const char* WIFI_PASSWORD = "YOUR_WIFI_PASSWORD";
```

The default settings use:

- OLED address: `0x3C`
- I2C SDA: GPIO 21
- I2C SCL: GPIO 22
- DHT data: GPIO 4
- DHT type: DHT22
- Time zone: Asia/Kolkata (UTC+5:30)

If you are using a DHT11, change:

```cpp
#define DHTTYPE DHT22
```

to:

```cpp
#define DHTTYPE DHT11
```

## Display behavior

The OLED shows:

- Current time
- Current date
- Temperature in °C
- Relative humidity in %

The ESP32 reconnects to Wi-Fi when necessary and periodically resynchronizes its clock from NTP.

## Project structure

```text
.
├── README.md
├── LICENSE
├── platformio.ini
└── src/
    └── esp32_smart_desk_monitor.ino
```

## Future ideas

Possible upgrades include a weather API, air-quality sensor, automatic brightness control, alarm/timer, min/max temperature history, CO₂ monitoring, room-status icons, and a more refined enclosure.

## Status

Latest prototype. Hardware enclosure and additional features are still being improved.

## License

MIT License. See `LICENSE`.
